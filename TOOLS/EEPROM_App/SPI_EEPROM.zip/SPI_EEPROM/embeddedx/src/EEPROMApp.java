// EEPROMApp.java
import com.fazecast.jSerialComm.SerialPort;
import javax.swing.*;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.concurrent.Executors;

class EEPROMSim {
    private final int[] memory;
    private final int size;

    public EEPROMSim(int size) {
        this.size = size;
        this.memory = new int[size];
    }

    public Integer readByte(int address) {
        if (address >= 0 && address < size) return memory[address];
        return null;
    }

    public boolean writeByte(int address, int value) {
        if (address >= 0 && address < size && value >= 0 && value <= 0xFF) {
            memory[address] = value;
            return true;
        }
        return false;
    }

    public int[] readAll(int size) {
        int len = Math.min(size, this.size);
        int[] result = new int[len];
        System.arraycopy(memory, 0, result, 0, len);
        return result;
    }

    public boolean writeAll(int[] values) {
        if (values.length <= size) {
            System.arraycopy(values, 0, memory, 0, values.length);
            return true;
        }
        return false;
    }
}

public class EEPROMApp {
    private static final int HEADER = 0xAA;
    private static final int TAIL = 0x55;

    // CMD IDs
    private static final int CMD_READ_BYTE = 0x01;
    private static final int CMD_WRITE_BYTE = 0x02;
    private static final int CMD_READ_ALL = 0x03;
    private static final int CMD_WRITE_ALL = 0x04;

    private JFrame frame;
    private JComboBox<String> portComboBox;
    private JTextArea log;
    private SerialPort serialPort;
    private volatile boolean running = false;
    private final EEPROMSim eeprom;

    public EEPROMApp() {
        eeprom = new EEPROMSim(1024);
        initUI();
    }

    private void initUI() {
        frame = new JFrame("SPI EEPROM Simulator (UART)");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);

        JLabel comLabel = new JLabel("Select COM Port:");
        gbc.gridx=0; gbc.gridy=0; frame.add(comLabel, gbc);

        portComboBox = new JComboBox<>(getComPorts());
        gbc.gridx=1; frame.add(portComboBox, gbc);

        JButton refreshBtn = new JButton("Refresh");
        refreshBtn.addActionListener(e -> refreshPorts());
        gbc.gridx=2; frame.add(refreshBtn, gbc);

        JButton connectBtn = new JButton("Connect");
        connectBtn.addActionListener(e -> connectSerial());
        gbc.gridx=3; frame.add(connectBtn, gbc);

        JButton readBtn = new JButton("Read Byte");
        readBtn.addActionListener(e -> readByteGui());
        gbc.gridx=0; gbc.gridy=1; frame.add(readBtn,gbc);

        JButton writeBtn = new JButton("Write Byte");
        writeBtn.addActionListener(e -> writeByteGui());
        gbc.gridx=1; frame.add(writeBtn,gbc);

        JButton readAllBtn = new JButton("Read All");
        readAllBtn.addActionListener(e -> readAllGui());
        gbc.gridx=2; frame.add(readAllBtn,gbc);

        JButton writeAllBtn = new JButton("Write All");
        writeAllBtn.addActionListener(e -> writeAllGui());
        gbc.gridx=3; frame.add(writeAllBtn,gbc);

        log = new JTextArea(20,80);
        log.setEditable(false);
        DefaultCaret caret = (DefaultCaret) log.getCaret();
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
        JScrollPane scrollPane = new JScrollPane(log);
        gbc.gridx=0; gbc.gridy=2; gbc.gridwidth=4;
        frame.add(scrollPane, gbc);

        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private String[] getComPorts() {
        SerialPort[] ports = SerialPort.getCommPorts();
        ArrayList<String> names = new ArrayList<>();
        for (SerialPort p: ports) names.add(p.getSystemPortName());
        if (names.isEmpty()) names.add("No COM Ports Found");
        return names.toArray(new String[0]);
    }

    private void refreshPorts() {
        portComboBox.setModel(new DefaultComboBoxModel<>(getComPorts()));
    }

    private void connectSerial() {
        String portName = (String) portComboBox.getSelectedItem();
        if (portName == null || portName.contains("No COM")) {
            JOptionPane.showMessageDialog(frame, "No COM Port selected", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        serialPort = SerialPort.getCommPort(portName);
        serialPort.setBaudRate(9600);
        serialPort.setComPortTimeouts(SerialPort.TIMEOUT_READ_BLOCKING, 1000, 0);
        if (serialPort.openPort()) {
            try {
                Thread.sleep(2000); // wait for Arduino reset
            } catch (InterruptedException ignored) {}
            running = true;
            Executors.newSingleThreadExecutor().submit(this::readFromSerial);
            log.append("[INFO] Connected to " + portName + "\n");
        } else {
            JOptionPane.showMessageDialog(frame, "Failed to open port", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // read raw bytes and assemble frames
    private void readFromSerial() {
        try {
            InputStream is = serialPort.getInputStream();
            byte[] buf = new byte[4096];
            int pos = 0;
            while (running && serialPort.isOpen()) {
                int b;
                try {
                    b = is.read(); // blocking with timeout set above
                } catch (IOException ex) {
                    if (ex.getMessage().contains("timed out")) {
                        // Timeout expected, no data yet
                        continue;
                    } else {
                        throw ex;
                    }
                }
                if (b < 0) continue;
                buf[pos++] = (byte)b;
                if (pos >= 7) {
                    int start = -1;
                    for (int i = 0; i <= pos - 1; ++i) {
                        if ((buf[i] & 0xFF) == HEADER) { start = i; break; }
                    }
                    if (start == -1) { pos = 0; continue; }
                    if (pos - start < 1 + 4 + 1 + 1) continue; // need len
                    int payloadLen = ((buf[start+1]&0xFF) << 24) | ((buf[start+2]&0xFF) << 16) |
                                     ((buf[start+3]&0xFF) << 8)  | (buf[start+4]&0xFF);
                    int total = 1 + 4 + payloadLen + 1;
                    if (pos - start < total) continue; // wait for rest
                    if ((buf[start + total - 1] & 0xFF) != TAIL) {
                        int newlen = pos - (start + 1);
                        if (newlen > 0) System.arraycopy(buf, start + 1, buf, 0, newlen);
                        pos = newlen;
                        continue;
                    }
                    byte[] frame = new byte[total];
                    System.arraycopy(buf, start, frame, 0, total);
                    decodeFrame(frame);
                    int rem = pos - (start + total);
                    if (rem > 0) System.arraycopy(buf, start + total, buf, 0, rem);
                    pos = rem;
                }
                if (pos >= buf.length) pos = 0;
            }
        } catch (IOException ex) {
            log.append("[ERROR] Serial read failed: " + ex.getMessage() + "\n");
        } catch (Exception e) {
            log.append("[ERROR] Serial read failed: " + e.getMessage() + "\n");
        }
    }

    // decode response frames and show human readable
    private void decodeFrame(byte[] frame) {
        if (frame == null || frame.length < 1+4+1+1) return;
        int payloadLen = ((frame[1]&0xFF) << 24) | ((frame[2]&0xFF) << 16) |
                         ((frame[3]&0xFF) << 8)  | (frame[4]&0xFF);
        int cmd = frame[5] & 0xFF;
        SwingUtilities.invokeLater(() -> {
            log.append("[RX FRAME] CMD=" + cmd + " payloadLen=" + payloadLen + "\n");
            try {
                int p = 6;
                switch (cmd) {
                    case CMD_READ_BYTE: {
                        if (payloadLen < 8) { log.append("[DECODE] Malformed READ_BYTE\n"); break; }
                        int addr = ((frame[p]&0xFF)<<24)|((frame[p+1]&0xFF)<<16)|((frame[p+2]&0xFF)<<8)|(frame[p+3]&0xFF);
                        int val  = ((frame[p+4]&0xFF)<<24)|((frame[p+5]&0xFF)<<16)|((frame[p+6]&0xFF)<<8)|(frame[p+7]&0xFF);
                        log.append("[DECODE] READ_BYTE -> addr=" + addr + " value=0x" + Integer.toHexString(val & 0xFF) + "\n");
                        break;
                    }
                    case CMD_WRITE_BYTE: {
                        if (payloadLen < 8) { log.append("[DECODE] Malformed WRITE_BYTE\n"); break; }
                        int addr = ((frame[p]&0xFF)<<24)|((frame[p+1]&0xFF)<<16)|((frame[p+2]&0xFF)<<8)|(frame[p+3]&0xFF);
                        int status = ((frame[p+4]&0xFF)<<24)|((frame[p+5]&0xFF)<<16)|((frame[p+6]&0xFF)<<8)|(frame[p+7]&0xFF);
                        log.append("[DECODE] WRITE_BYTE -> addr=" + addr + " status=" + status + "\n");
                        break;
                    }
                    case CMD_READ_ALL: {
                        if (payloadLen < 4) { log.append("[DECODE] Malformed READ_ALL\n"); break; }
                        int size = ((frame[p]&0xFF)<<24)|((frame[p+1]&0xFF)<<16)|((frame[p+2]&0xFF)<<8)|(frame[p+3]&0xFF);
                        log.append("[DECODE] READ_ALL -> size=" + size + " data=[");
                        for (int i=0;i<size;i++) {
                            log.append(String.valueOf(frame[p+4+i]&0xFF));
                            if (i < size-1) log.append(",");
                        }
                        log.append("]\n");
                        break;
                    }
                    case CMD_WRITE_ALL: {
                        if (payloadLen < 8) { log.append("[DECODE] Malformed WRITE_ALL\n"); break; }
                        int size = ((frame[p]&0xFF)<<24)|((frame[p+1]&0xFF)<<16)|((frame[p+2]&0xFF)<<8)|(frame[p+3]&0xFF);
                        int status = ((frame[p+4]&0xFF)<<24)|((frame[p+5]&0xFF)<<16)|((frame[p+6]&0xFF)<<8)|(frame[p+7]&0xFF);
                        log.append("[DECODE] WRITE_ALL -> size=" + size + " status=" + status + "\n");
                        break;
                    }
                    default:
                        log.append("[DECODE] Unknown CMD=" + cmd + "\n");
                }
            } catch (Exception ex) {
                log.append("[DECODE] Error decoding frame: " + ex.getMessage() + "\n");
            }
        });
    }

    // helper: build and send a simple request with two 32-bit params (big-endian)
    private void sendSimpleFrame(int cmd, int p1, int p2) {
        if (serialPort == null || !serialPort.isOpen()) { log.append("[ERROR] Serial port not open\n"); return; }
        try {
            byte[] frame = new byte[1 + 4 + 1 + 4 + 4 + 1];
            int idx = 0;
            frame[idx++] = (byte) HEADER;
            // payload length = 1 (cmd) + 4 + 4 = 9
            frame[idx++] = 0; frame[idx++] = 0; frame[idx++] = 0; frame[idx++] = 9; // big-endian
            frame[idx++] = (byte) cmd;
            frame[idx++] = (byte) ((p1 >> 24) & 0xFF);
            frame[idx++] = (byte) ((p1 >> 16) & 0xFF);
            frame[idx++] = (byte) ((p1 >> 8) & 0xFF);
            frame[idx++] = (byte) (p1 & 0xFF);
            frame[idx++] = (byte) ((p2 >> 24) & 0xFF);
            frame[idx++] = (byte) ((p2 >> 16) & 0xFF);
            frame[idx++] = (byte) ((p2 >> 8) & 0xFF);
            frame[idx++] = (byte) (p2 & 0xFF);
            frame[idx++] = (byte) TAIL;
            serialPort.getOutputStream().write(frame);
            serialPort.getOutputStream().flush();
            log.append("[TX] Sent frame CMD=" + cmd + ", P1=" + p1 + ", P2=" + p2 + "\n");
        } catch (IOException ex) {
            log.append("[ERROR] Failed to send frame: " + ex.getMessage() + "\n");
        }
    }

    // helper: send WRITE_ALL request: cmd + size(4) + data[size]
    private void sendWriteAllFrame(int cmd, int size, byte[] data) {
        if (serialPort == null || !serialPort.isOpen()) { log.append("[ERROR] Serial port not open\n"); return; }
        if (size != data.length) { log.append("[ERROR] size mismatch\n"); return; }
        try {
            int payloadLen = 1 + 4 + size; // cmd(1) + size(4) + data
            int total = 1 + 4 + payloadLen + 1;
            byte[] frame = new byte[total];
            int idx = 0;
            frame[idx++] = (byte) HEADER;
            // length = payloadLen
            frame[idx++] = (byte) ((payloadLen >> 24) & 0xFF);
            frame[idx++] = (byte) ((payloadLen >> 16) & 0xFF);
            frame[idx++] = (byte) ((payloadLen >> 8) & 0xFF);
            frame[idx++] = (byte) (payloadLen & 0xFF);
            frame[idx++] = (byte) cmd;
            // size as 4 bytes
            frame[idx++] = (byte) ((size >> 24) & 0xFF);
            frame[idx++] = (byte) ((size >> 16) & 0xFF);
            frame[idx++] = (byte) ((size >> 8) & 0xFF);
            frame[idx++] = (byte) (size & 0xFF);
            // data
            System.arraycopy(data, 0, frame, idx, size);
            idx += size;
            frame[idx++] = (byte) TAIL;
            serialPort.getOutputStream().write(frame);
            serialPort.getOutputStream().flush();
            log.append("[TX] Sent WRITE_ALL frame size=" + size + "\n");
        } catch (IOException ex) {
            log.append("[ERROR] Failed to send frame: " + ex.getMessage() + "\n");
        }
    }

    // GUI actions
    private void readByteGui() {
        String input = JOptionPane.showInputDialog(frame, "Enter address (0-1023):");
        if (input == null) return;
        int addr = Integer.parseInt(input.trim());
        log.append("[CMD] Read Byte @ " + addr + "\n");
        sendSimpleFrame(CMD_READ_BYTE, addr, 0);
    }

    private void writeByteGui() {
        String addrStr = JOptionPane.showInputDialog(frame, "Enter address (0-1023):");
        if (addrStr == null) return;
        String valStr = JOptionPane.showInputDialog(frame, "Enter value (0-255):");
        if (valStr == null) return;
        int addr = Integer.parseInt(addrStr.trim());
        int val = Integer.parseInt(valStr.trim());
        log.append("[CMD] Write Byte @ " + addr + " = " + val + "\n");
        sendSimpleFrame(CMD_WRITE_BYTE, addr, val);
    }

    private void readAllGui() {
        String sizeStr = JOptionPane.showInputDialog(frame, "Enter size (1-1024):");
        if (sizeStr == null) return;
        int size = Integer.parseInt(sizeStr.trim());
        log.append("[CMD] Read All " + size + "\n");
        sendSimpleFrame(CMD_READ_ALL, size, 0);
    }

    private void writeAllGui() {
        String input = JOptionPane.showInputDialog(frame, "Enter comma-separated values (0-255):");
        if (input == null) return;
        try {
            String[] parts = input.split(",");
            int[] vals = new int[parts.length];
            byte[] data = new byte[parts.length];
            for (int i=0;i<parts.length;i++) {
                vals[i] = Integer.parseInt(parts[i].trim());
                data[i] = (byte)(vals[i] & 0xFF);
            }
            boolean ok = eeprom.writeAll(vals); // local sim
            log.append("[CMD] Write All " + vals.length + " -> " + (ok ? "OK" : "Fail") + "\n");
            sendWriteAllFrame(CMD_WRITE_ALL, vals.length, data);
        } catch (Exception ex) {
            log.append("[ERROR] Invalid input\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(EEPROMApp::new);
    }
}
